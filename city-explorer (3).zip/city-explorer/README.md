# City Explorer 

Am creat un site de prezentare a unor destinatii turistice in cadrul disciplinei Tehnologii Web. 

Leonte Laura-Andreea (633AB)