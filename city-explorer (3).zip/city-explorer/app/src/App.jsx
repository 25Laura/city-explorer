import { useState } from 'react';
import { destinatii as destinatiiInitiale } from './data/destinatii.js';
import {
  getNevizitate,
  totalZile,
  marcheazaVizitat,
  adaugaDestinatie
} from './utils/destinatii.js';

import Rezumat from './components/Rezumat.jsx';
import FormularDestinatie from './components/FormularDestinatie.jsx';
import ListaDestinatii from './components/ListaDestinatii.jsx';
import './App.css';

export default function App() {
  const [destinatii, setDestinatii] = useState(destinatiiInitiale);

  function handleToggle(id) {
    setDestinatii((curent) => marcheazaVizitat(curent, id));
  }

  function handleAdd(destinatieNoua) {
    setDestinatii((curent) => adaugaDestinatie(curent, destinatieNoua));
  }

  const nevizitateList = getNevizitate(destinatii);
  const total = destinatii.length;
  const nevizitate = nevizitateList.length;
  const zile = totalZile(nevizitateList);

  return (
    <main>
      <h1>City Explorer</h1>
      <Rezumat total={total} nevizitate={nevizitate} zile={zile} />
      <FormularDestinatie onAdd={handleAdd} />
      <ListaDestinatii destinatii={destinatii} onToggle={handleToggle} />
    </main>
  );
}